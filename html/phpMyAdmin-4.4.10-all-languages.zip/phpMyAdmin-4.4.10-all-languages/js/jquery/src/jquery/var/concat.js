define([
	"./deletedIds"
], function( deletedIds ) {
	return deletedIds.concat;
});
